import { mkdir, readFile, writeFile } from "node:fs/promises";

const source = await readFile("src/GiftCraft.jsx", "utf8");
const appSource = source
  .replace(/import\s+\{\s*useState\s*,\s*useEffect\s*\}\s+from\s+["']react["'];?\s*/, "")
  .replace(/export\s+default\s+function\s+GiftCraft\s*\(/, "function GiftCraft(");

const html = `<!doctype html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>GiftCraft</title>
    <style>
      html,
      body,
      #root {
        margin: 0;
        min-height: 100%;
        background: #050d1f;
      }

      body {
        min-height: 100vh;
      }
    </style>
  </head>
  <body>
    <div id="root"></div>
    <script crossorigin src="https://unpkg.com/react@18/umd/react.production.min.js"></script>
    <script crossorigin src="https://unpkg.com/react-dom@18/umd/react-dom.production.min.js"></script>
    <script src="https://unpkg.com/@babel/standalone/babel.min.js"></script>
    <script type="text/babel" data-presets="react">
      const { useState, useEffect } = React;

${appSource}

      ReactDOM.createRoot(document.getElementById("root")).render(<GiftCraft />);
    </script>
  </body>
</html>
`;

await writeFile("index.html", html, "utf8");
await mkdir("dist", { recursive: true });
await writeFile("dist/index.html", html, "utf8");
